import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';


export default function One() {
  const [password, setPassword] = useState('');
  const email = localStorage.getItem('email'); // Retrieve email from localStorage
  const navigate = useNavigate();

  const handlePasswordSubmit = (event) => {
    event.preventDefault();
    if (password) {
      localStorage.setItem('password', password); // Store password in localStorage
      navigate('/two'); // Redirect to the next page
    }
  };

  return (
    <div>
    <img src={require('../assets/image/Netflix-logo.png')} id='logo'/>
    <br></br>
    <Link to={'/Login'}>
        <button id='one-select'>SIGN IN</button>
    </Link>
    <br></br><br></br>
    <hr></hr>
    <br></br><br></br>
    
    <div id='one-elements'>    
      <h5 id='one-step'>Step 1 of 2</h5>
      <br></br>
      <h3>Welcome Back!<br></br>Joining Netflix is Easy</h3>
      <br></br>
      <h5>Enter your Password and you'll be watching<br></br>in no time</h5>
      <br></br>
      <h5>Email:<br></br> {email}</h5>
      <br></br>
      <form onSubmit={handlePasswordSubmit}>
        <input
          id="one-email"
          type="password"
          placeholder="Enter Your Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        /><br></br><br></br>
        <a href="/Forgot" id="one-forgot">Forgot Password?</a><br></br><br></br>
        <button type="submit" id='one-button'>Next</button>
      </form>
      <br></br>
    </div>
    </div>
  );
}
