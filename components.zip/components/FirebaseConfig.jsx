import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth"; // For Firebase Authentication
import { getFirestore } from "firebase/firestore"; // For Firestore database
import { getStorage } from "firebase/storage"; // For Firebase Storage

// Firebase configuration object
const firebaseConfig = {
  apiKey: "AIzaSyD8v5CmsujmV0BP9qrhW7t0jtXERlH04c8",
  authDomain: "netflix-6da71.firebaseapp.com",
  projectId: "netflix-6da71",
  storageBucket: "netflix-6da71.appspot.com",
  messagingSenderId: "756878044762",
  appId: "1:756878044762:web:6455241983e0875309b263",
  measurementId: "G-RVTBJ4JHZR", // Optional: Use for analytics if required
};

// Initialize Firebase app
const app = initializeApp(firebaseConfig);

// Initialize Firebase services and export them
export const auth = getAuth(app); // Firebase Authentication instance
export const db = getFirestore(app); // Firestore database instance
export const storage = getStorage(app); // Firebase Storage instance

// Export the Firebase app instance (optional, only if needed elsewhere)
export default app;