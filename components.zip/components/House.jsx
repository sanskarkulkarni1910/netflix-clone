import React, { useState } from 'react';
import backgroundImage from '../assets/image/black1.png'; 
import logoImage from '../assets/image/Netflix-logo.png'; 

export default function House() {
  // State to control dropdown visibility
  const [isDropdownVisible, setIsDropdownVisible] = useState(false);

  // Function to toggle dropdown visibility
  const toggleDropdown = () => {
    setIsDropdownVisible(!isDropdownVisible);
  };

  // Function to close the dropdown after link click
  const handleLinkClick = () => {
    setIsDropdownVisible(false); 
  };
  return (
    <div id="header-container">
      <div className="overlay"></div>
      <img src={logoImage} id="logo" alt="Logo" />
        <div id="content" style={{ backgroundImage: `url(${backgroundImage})` }}>

          <nav>
            <img src={logoImage} id="logo" alt="Logo" />
            <br />
            <button id="house-navbar">HOME</button>
            <button id="house-navbar1"><a href="/Shows">SHOWS</a></button>
            <button id="house-navbar2"><a href="/Movie">MOVIES</a></button>

            {/* Dropdown button after Movies */}
            <button id='house-togglerbutton'
              onClick={toggleDropdown}
            >
              <button id='house-navbar4'>CINEMAS <i class="fa-solid fa-caret-down"></i></button>
            </button>      
            
           &nbsp;&nbsp; <button style={{backgroundColor: 'red'}}><a href="/Login">SIGN OUT</a></button>

            <hr id='house-hr'></hr>
          </nav>

          <br></br>

          <h5 id='popular'>TRENDING</h5>
          <span id='shows'>Trending shows and movies are currently the most <br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;popular among viewers.</span>
          <img src={require('../assets/image/red.png')} alt="Red" id='hrt1'></img>
          <br></br><br></br>

            <div class="banner-container">
                <div class="" id='big-banner'>                    
                  <a href="https://www.youtube.com/watch?v=1Bll53fBa9U"><img src={require('../assets/image/big-banner.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                    <a href="https://www.youtube.com/watch?v=AkUgf2jIPyI"><img src={require('../assets/image/smallbanner1.webp')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                    <a href="https://www.youtube.com/watch?v=jNuKwlKJx2E"><img src={require('../assets/image/smallbanner2.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                    <a href="https://youtube.com/watch?v=Kv5RKsqVe-Y"><img src={require('../assets/image/smallbanner3.avif')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                    <a href="https://www.youtube.com/watch?v=iM150ZWovZM"><img src={require('../assets/image/smallbanner4.avif')} alt="Red" id='big-banner-img'></img></a>
                </div>

            </div>

            <br></br><br></br>
            <h5 id='popular'>POPULAR ON NETFLIX</h5>
            <span id='shows'>Popular on Netflix right now are the latest blockbuster <br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;movies and trending TV shows.</span>
            <img src={require('../assets/image/red.png')} alt="Red" id='hrt1'></img>
            <br></br><br></br>

            {/* Dropdown menu */}
            {isDropdownVisible && (
              <div className="dropdown-content" id='house-content'><br></br>
                <a href="/Hollywood" onClick={handleLinkClick}>HollyWood</a> 
                <a href="/Bollywood" onClick={handleLinkClick}>BollyWood</a>
                <br></br> <br></br>
              </div>
            )}
            
          <div class="banner-container">
                <div class="banner" id='big-banner'>                    
                  <a href="https://www.youtube.com/watch?v=q4RK3jY7AVk"><img src={require('../assets/image/2banner1.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                  <a href="https://www.youtube.com/watch?v=XvnJWKOv3c4"><img src={require('../assets/image/2banner2.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                  <a href="https://www.youtube.com/watch?v=1Bpgmv3HTYs"><img src={require('../assets/image/2banner3.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                  <a href="https://www.youtube.com/watch?v=HnG4ag3Nkes"><img src={require('../assets/image/2banner4.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                  <a href="https://www.youtube.com/watch?v=uQBy6jqbmlU"><img src={require('../assets/image/2banner5.jpeg')} alt="Red" id='big-banner-img'></img></a>
                </div>
                
                <div class="banner" id='big-banner'>
                  <a href="https://www.youtube.com/watch?v=x7E-ku5KzKw"><img src={require('../assets/image/2banner6.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>
            </div>

            <br></br><br></br>
            <h5 id='popular'>DRAMA</h5>
            <span id='shows'>Drama series often capture intense emotions and complex storylines, <br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;keeping viewers on the edge of their seats.</span>
            <img src={require('../assets/image/red.png')} alt="Red" id='hrt1'></img>
            <br></br><br></br> 

            <div class="banner-container">
                <div id='big-banner'>                    
                    <a href="https://www.youtube.com/watch?v=Gg2D8zrzlOA"><img src={require('../assets/image/3banner1.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div id='big-banner'>
                <a href="https://www.youtube.com/watch?v=Ruyl8_PT_y8"><img src={require('../assets/image/3banner2.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div  id='big-banner'>
                <a href="https://www.youtube.com/watch?v=bQRCyrNmhj4"><img src={require('../assets/image/3banner3.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>
            </div>

            <br></br><br></br>
            <h5 id='popular'> COMEDY</h5>
            <span id='shows'>Comedy films and shows on Netflix are filled with humor and light-hearted <br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;moments that make for the perfect escape after a long day.
            </span>

            <img src={require('../assets/image/red.png')} alt="Red" id='hrt1'></img>
            <br></br><br></br>

            <div class="banner-container">
                <div class="banner1" id='big-banner1'>                    
                <a href="https://www.youtube.com/watch?v=-xR_lBtEvSc"><img src={require('../assets/image/4banner1.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner2" id='big-banner1'>
                <a href="https://www.youtube.com/watch?v=gAhgC6llaKg"><img src={require('../assets/image/4banner2.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>
            </div>

            <div class="banner-container">
                <div class="banner2" id='big-banner1'>                    
                <a href="https://www.youtube.com/watch?v=B7VP47oCZfE"> <img src={require('../assets/image/4banner3.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner1" id='big-banner1'>
                <a href="https://www.youtube.com/watch?v=TuJ3mM001Os"><img src={require('../assets/image/4banner4.png')} alt="Red" id='big-banner-img'></img></a>
                </div>
            </div>
            
            <br></br><br></br>
        </div>
        <div id='footer'><br></br>
          <span id="question">Questions? Call 000-800-919-1743</span>
            <div class="container mt-5">
                <div class="row">
                    <div class="col-md-3">
                        <div class="card1">
                            <div class="card-body">
                                <h5 class="card-title">FAQ</h5>
                                <h5 class="card-title">Invsetor relations</h5>
                                <h5 class="card-title">Privacy</h5>
                                <h5 class="card-title">Speed Test</h5>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card1">
                            <div class="card-body">
                                <h5 class="card-title">Help Center</h5>
                                <h5 class="card-title">Jobs</h5>
                                <h5 class="card-title">Cookie Preferences</h5>
                                <h5 class="card-title">Legal Notices</h5>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card1">
                            <div class="card-body">
                                <h5 class="card-title">Account</h5>
                                <h5 class="card-title">Ways to Watch</h5>
                                <h5 class="card-title">Information</h5>
                                <h5 class="card-title">Only On Netflix</h5>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card1">
                            <div class="card-body">
                                <h5 class="card-title">Media Center</h5>
                                <h5 class="card-title">Terms of Use</h5>
                                <h5 class="card-title">Contact us</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <br></br><br></br><br></br>
          <span id="india">Netflix India</span>
          <br></br><br></br><br></br>
        </div>
    </div>
  );
}
