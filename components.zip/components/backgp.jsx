import React, { useState } from 'react';
import backgroundImage from '../assets/image/black1.png'; 
import logoImage from '../assets/image/Netflix-logo.png'; 

export default function House() {
  // State to control dropdown visibility
  const [isDropdownVisible, setIsDropdownVisible] = useState(false);
  const [searchQuery, setSearchQuery] = useState(''); // state for search query
  const [filteredContent, setFilteredContent] = useState([]); // state for search results

  // Dummy data for content (Replace with your actual content or API data)
  const contentData = [
    { title: 'Movie 1', category: 'Trending' },
    { title: 'Movie 2', category: 'Drama' },
    { title: 'Comedy Show 1', category: 'Comedy' },
    { title: 'Action Movie', category: 'Trending' },
    { title: 'Show 3', category: 'Drama' },
    { title: 'Movie 4', category: 'Comedy' },
    // Add more items here
  ];

  // Function to toggle dropdown visibility
  const toggleDropdown = () => {
    setIsDropdownVisible(!isDropdownVisible);
  };

  // Function to close the dropdown after link click
  const handleLinkClick = () => {
    setIsDropdownVisible(false); 
  };

  // Function to handle search input change
  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value); // update searchQuery on input change
  };

  // Function to handle search submit and filter content
  const handleSearchSubmit = (e) => {
    e.preventDefault();
    // Filter content based on the search query
    const results = contentData.filter((item) =>
      item.title.toLowerCase().includes(searchQuery.toLowerCase())
    );
    setFilteredContent(results); // Update the filtered content state
    console.log("Search results:", results); // You can choose to render these in a list or further process
  };

  return (
    <div id="header-container">
      <div className="overlay"></div>
      <img src={logoImage} id="logo" alt="Logo" />
      <div id="content" style={{ backgroundImage: `url(${backgroundImage})` }}>

        <nav>
          <img src={logoImage} id="logo" alt="Logo" />
          <br />
          <button id="house-navbar"><a href="">HOME</a></button>
          <button id="house-navbar1"><a href="">SHOWS</a></button>
          <button id="house-navbar2"><a href="">MOVIES</a></button>

          {/* Dropdown button after Movies */}
          <button id='house-togglerbutton' onClick={toggleDropdown}>
            <button id='house-navbar4'>CINEMAS <i className="fa-solid fa-caret-down"></i></button>
          </button>
          <a href=""><i className="fa-solid fa-user" id='user'></i></a>

          <br></br>
          <hr id='house-hr'></hr>
        </nav>

        <br></br>

            {/* Search bar */}
            <form id="search-form" onSubmit={handleSearchSubmit}>
              <input 
                type="text" 
                placeholder="Search..." 
                id="search-bar" 
                value={searchQuery} 
                onChange={handleSearchChange} 
              />
            </form>

            {/* Display search results */}
          {filteredContent.length > 0 ? (
            <div className="search-results">
              <h5>Search Results:</h5>
              <ul>
                {filteredContent.map((item, index) => (
                  <li key={index}>{item.title} ({item.category})</li>
                ))}
              </ul>
            </div>
          ) : (
            searchQuery && <p id='searchresult'>No results found for "{searchQuery}"</p> // Show message if no results
          )}

        <h5 id='popular'>TRENDING</h5>
        <span id='shows'>Trending shows and movies are currently the most <br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;popular among viewers.</span>        
        <img src={require('../assets/image/red.png')} alt="Red" id='hrt1'></img>
        <br></br><br></br>

        {/* Banner images */}
        <div className="banner-container">
          <div className="" id='big-banner'>                    
            <img src={require('../assets/image/big-banner.jpg')} alt="Red" id='big-banner-img'></img>
          </div>

          <div className="banner" id='big-banner'>
            <img src={require('../assets/image/smallbanner1.webp')} alt="Red" id='big-banner-img'></img>
          </div>

          <div className="banner" id='big-banner'>
            <img src={require('../assets/image/smallbanner2.jpg')} alt="Red" id='big-banner-img'></img>
          </div>

          <div className="banner" id='big-banner'>
            <img src={require('../assets/image/smallbanner3.avif')} alt="Red" id='big-banner-img'></img>
          </div>

          <div className="banner" id='big-banner'>
            <img src={require('../assets/image/smallbanner4.avif')} alt="Red" id='big-banner-img'></img>
          </div>

        </div>

        <br></br><br></br>
        <h5 id='popular'>POPULAR ON NETFLIX</h5>
        <span id='shows'>Popular on Netflix right now are the latest blockbuster <br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;movies and trending TV shows.</span>
        <img src={require('../assets/image/red.png')} alt="Red" id='hrt1'></img>
        <br></br><br></br>

        {/* Dropdown menu */}
        {isDropdownVisible && (
          <div className="dropdown-content" id='house-content'><br></br>
            <a href="#" onClick={handleLinkClick}>HollyWood</a> 
            <a href="#" onClick={handleLinkClick}>BollyWood</a>
            <br></br> <br></br>
          </div>
        )}

        <div className="banner-container">
          <div className="banner" id='big-banner'>                    
            <img src={require('../assets/image/2banner1.jpg')} alt="Red" id='big-banner-img'></img>
          </div>

          <div className="banner" id='big-banner'>
            <img src={require('../assets/image/2banner2.jpg')} alt="Red" id='big-banner-img'></img>
          </div>

          <div className="banner" id='big-banner'>
            <img src={require('../assets/image/2banner3.jpg')} alt="Red" id='big-banner-img'></img>
          </div>

          <div className="banner" id='big-banner'>
            <img src={require('../assets/image/2banner4.jpg')} alt="Red" id='big-banner-img'></img>
          </div>

          <div className="banner" id='big-banner'>
            <img src={require('../assets/image/2banner5.jpeg')} alt="Red" id='big-banner-img'></img>
          </div>

          <div className="banner" id='big-banner'>
            <img src={require('../assets/image/2banner6.jpg')} alt="Red" id='big-banner-img'></img>
          </div>
        </div>

        <br></br><br></br>
        <h5 id='popular'>DRAMA</h5>
        <span id='shows'>Drama series often capture intense emotions and complex storylines, <br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;keeping viewers on the edge of their seats.</span>
        <img src={require('../assets/image/red.png')} alt="Red" id='hrt1'></img>
        <br></br><br></br> 

        <div className="banner-container">
          <div id='big-banner'>                    
            <img src={require('../assets/image/3banner1.jpg')} alt="Red" id='big-banner-img'></img>
          </div>

          <div id='big-banner'>
            <img src={require('../assets/image/3banner2.jpg')} alt="Red" id='big-banner-img'></img>
          </div>

          <div  id='big-banner'>
            <img src={require('../assets/image/3banner3.jpg')} alt="Red" id='big-banner-img'></img>
          </div>
        </div>

        <br></br><br></br>
        <h5 id='popular'> COMEDY</h5>
        <span id='shows'>Comedy films and shows on Netflix are filled with humor and light-hearted <br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;moments that make for the perfect escape after a long day.</span>

        <img src={require('../assets/image/red.png')} alt="Red" id='hrt1'></img>
        <br></br><br></br>

        <div className="banner-container">
          <div className="banner1" id='big-banner1'>                    
            <img src={require('../assets/image/4banner1.jpg')} alt="Red" id='big-banner-img'></img>
          </div>

          <div className="banner2" id='big-banner1'>
            <img src={require('../assets/image/4banner2.jpg')} alt="Red" id='big-banner-img'></img>
          </div>
        </div>

        <div className="banner-container">
          <div className="banner2" id='big-banner1'>                    
            <img src={require('../assets/image/4banner3.jpg')} alt="Red" id='big-banner-img'></img>
          </div>

          <div className="banner1" id='big-banner1'>
            <img src={require('../assets/image/4banner4.png')} alt="Red" id='big-banner-img'></img>
          </div>
        </div>

        <br></br><br></br>
      </div>
      <div id='footer'>
        <br></br>
        <span id="ready">Ready to watch? Enter your email to create or restart your membership.</span><br></br><br></br>
        <form id="usernameForm" action="/One" method="GET">
          <input type="text" placeholder="Enter Your Username" id="text1" name="username" required />
          <button type="submit" id="get">Get Started &nbsp;&nbsp;<i className="fa-solid fa-greater-than"></i></button>
        </form>

        <br /><br /><br /><br /><br />
        <span id="question">Questions? Call 000-800-919-1743</span>
        <div className="container mt-5">
          <div className="row">
            <div className="col-md-3">
              <div className="card1">
                <div className="card-body">
                  <h5 className="card-title">FAQ</h5>
                  <h5 className="card-title">Investor relations</h5>
                  <h5 className="card-title">Privacy</h5>
                  <h5 className="card-title">Speed Test</h5>
                </div>
              </div>
            </div>

            <div className="col-md-3">
              <div className="card1">
                <div className="card-body">
                  <h5 className="card-title">Help Center</h5>
                  <h5 className="card-title">Jobs</h5>
                  <h5 className="card-title">Cookie Preferences</h5>
                  <h5 className="card-title">Legal Notices</h5>
                </div>
              </div>
            </div>

            <div className="col-md-3">
              <div className="card1">
                <div className="card-body">
                  <h5 className="card-title">Account</h5>
                  <h5 className="card-title">Ways to Watch</h5>
                  <h5 className="card-title">Information</h5>
                  <h5 className="card-title">Only On Netflix</h5>
                </div>
              </div>
            </div>

            <div className="col-md-3">
              <div className="card1">
                <div className="card-body">
                  <h5 className="card-title">Media Center</h5>
                  <h5 className="card-title">Terms of Use</h5>
                  <h5 className="card-title">Contact us</h5>
                </div>
              </div>
            </div>
          </div>
          
        </div>
        <br></br><br></br><br></br>
        <span id="india">Netflix India</span>
        <br></br><br></br><br></br>
      </div>
    </div>
  );
}
