import React, { useState } from 'react';
import backgroundImage from '../assets/image/black1.png'; 
import logoImage from '../assets/image/Netflix-logo.png'; 

export default function Shows() {
  // State to control dropdown visibility
  const [isDropdownVisible, setIsDropdownVisible] = useState(false);

  // Function to toggle dropdown visibility
  const toggleDropdown = () => {
    setIsDropdownVisible(!isDropdownVisible);
  };

  // Function to close the dropdown after link click
  const handleLinkClick = () => {
    setIsDropdownVisible(false); 
  };

  return (
    <div id="header-container">
      <div className="overlay"></div>
      <img src={logoImage} id="logo" alt="Logo" />
        <div id="content" style={{ backgroundImage: `url(${backgroundImage})` }}>

          <nav>
            <img src={logoImage} id="logo" alt="Logo" />
            <br />
            <button id="house-navbar5"><a href="/House">HOME</a></button>
            <button id="house-navbar6">SHOWS</button>       

            <br></br><br></br>
            <hr id='house-hr'></hr>
          </nav>
          
            <br></br>
            <h5 id='popular'>HORROR</h5>
            <img src={require('../assets/image/red.png')} alt="Red" id='hrt2'></img>
            <br></br><br></br>         
            
             <div class="banner-container">
                <div id='big-banner'>
                <a href="https://www.youtube.com/watch?v=Di310WS8zLk"><img src={require('../../src/assets/image/Other/Horror/1.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=6sxnOLRGkhw"><img src={require('../../src/assets/image/Other/Horror/3.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=1PgKjIosF50"><img src={require('../../src/assets/image/Other/Horror/4.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=89UV8vmWXlY"><img src={require('../../src/assets/image/Other/Horror/5.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=zg0N4L4mwFk"><img src={require('../../src/assets/image/Other/Horror/6.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>
            </div>

            <br></br><br></br>
            <h5 id='popular'>COMEDY</h5>
            <img src={require('../assets/image/red.png')} alt="Red" id='hrt2'></img>
            <br></br><br></br>  
            <div class="banner-container">
                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=ZOA_EvRvqJU"><img src={require('../../src/assets/image/Other/Comedy/1.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=N9TtrkQQm4s"><img src={require('../../src/assets/image/Other/Comedy/2.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=DUAouyG91io"><img src={require('../../src/assets/image/Other/Comedy/3.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=JKufPJ-JHvA"><img src={require('../../src/assets/image/Other/Comedy/4.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div  id='big-banner'>
                <a href="https://www.youtube.com/watch?v=85z53bAebsI"><img src={require('../../src/assets/image/Other/Comedy/5.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

            </div>

            <br></br><br></br>
            <h5 id='popular'>NARRATIVE</h5>
            <img src={require('../assets/image/red.png')} alt="Red" id='hrt2'></img>
            <br></br><br></br>  
            <div class="banner-container">
                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=K83366UdtXw"><img src={require('../../src/assets/image/Other/Narrative/1.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=fdu10cX3pWA"><img src={require('../../src/assets/image/Other/Narrative/2.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div id='big-banner'>
                <a href="https://www.youtube.com/watch?v=UXBJODa1Dm8"><img src={require('../../src/assets/image/Other/Narrative/3.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=UiSfup00uZY"><img src={require('../../src/assets/image/Other/Narrative/4.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=mRzp4nGh4CM"><img src={require('../../src/assets/image/Other/Narrative/5.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

            </div>

            <br></br><br></br>
            <h5 id='popular'>KIDS</h5>
            <img src={require('../assets/image/red.png')} alt="Red" id='hrt2'></img>
            <br></br><br></br>  
            <div class="banner-container">
                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=t-D174c-mr0"><img src={require('../../src/assets/image/Other/Kids/1.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=HSoXY7l2cx4"><img src={require('../../src/assets/image/Other/Kids/2.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=p0JP44vWSNY"><img src={require('../../src/assets/image/Other/Kids/3.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=NcOoI52rv6Y"><img src={require('../../src/assets/image/Other/Kids/4.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=5ptxxlU5Oh4"><img src={require('../../src/assets/image/Other/Kids/5.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=gBZ9UkhblkM"><img src={require('../../src/assets/image/Other/Kids/6.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

            </div>
            
        <div id='footer'><br></br><br></br><br></br>
          <span id="question">Questions? Call 000-800-919-1743</span>
          <div class="container mt-5">
              <div class="row">
                  <div class="col-md-3">
                      <div class="card1">
                          <div class="card-body">
                              <h5 class="card-title">FAQ</h5>
                              <h5 class="card-title">Invsetor relations</h5>
                              <h5 class="card-title">Privacy</h5>
                              <h5 class="card-title">Speed Test</h5>
                          </div>
                      </div>
                  </div>

                  <div class="col-md-3">
                      <div class="card1">
                          <div class="card-body">
                              <h5 class="card-title">Help Center</h5>
                              <h5 class="card-title">Jobs</h5>
                              <h5 class="card-title">Cookie Preferences</h5>
                              <h5 class="card-title">Legal Notices</h5>
                          </div>
                      </div>
                  </div>

                  <div class="col-md-3">
                      <div class="card1">
                          <div class="card-body">
                              <h5 class="card-title">Account</h5>
                              <h5 class="card-title">Ways to Watch</h5>
                              <h5 class="card-title">Information</h5>
                              <h5 class="card-title">Only On Netflix</h5>
                          </div>
                      </div>
                  </div>

                  <div class="col-md-3">
                      <div class="card1">
                          <div class="card-body">
                              <h5 class="card-title">Media Center</h5>
                              <h5 class="card-title">Terms of Use</h5>
                              <h5 class="card-title">Contact us</h5>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
          <br></br><br></br><br></br>
          <span id="india">Netflix India</span>
          <br></br><br></br><br></br>
        </div>
      </div>
    </div>
  );
}
