import React, { useState } from 'react';
import backgroundImage from '../assets/image/black1.png'; 
import logoImage from '../assets/image/Netflix-logo.png'; 

export default function Hollywood() {
  // State to control dropdown visibility
  const [isDropdownVisible, setIsDropdownVisible] = useState(false);

  // Function to toggle dropdown visibility
  const toggleDropdown = () => {
    setIsDropdownVisible(!isDropdownVisible);
  };

  // Function to close the dropdown after link click
  const handleLinkClick = () => {
    setIsDropdownVisible(false); 
  };

  return (
    <div id="header-container">
      <div className="overlay"></div>
      <img src={logoImage} id="logo" alt="Logo" />
        <div id="content" style={{ backgroundImage: `url(${backgroundImage})` }}>

          <nav>
            <img src={logoImage} id="logo" alt="Logo" />
            <br />
            <button id="house-navbar5"><a href="/House">HOME</a></button>
            <button id="house-navbar6">HOLLYWOOD</button>       

            <br></br><br></br>
            <hr id='house-hr'></hr>
          </nav>
          
            <br></br>
            <h5 id='popular'>HORROR</h5>
            <img src={require('../assets/image/red.png')} alt="Red" id='hrt2'></img>
            <br></br><br></br>         
            
             <div class="banner-container">
                <div id='big-banner'>
                <a href="https://www.youtube.com/watch?v=smWoXS5roXQ"><img src={require('../../src/assets/image/Other/Cinemas/Hollywood/Horror/1.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=YJXqvnT_rsk"><img src={require('../../src/assets/image/Other/Cinemas/Hollywood/Horror/2.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=ECPfXUW0zt8"><img src={require('../../src/assets/image/Other/Cinemas/Hollywood/Horror/3.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=_EaEllq5FLk"><img src={require('../../src/assets/image/Other/Cinemas/Hollywood/Horror/4.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=vPPz8qYRO24"><img src={require('../../src/assets/image/Other/Cinemas/Hollywood/Horror/5.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>
            </div>

            <br></br><br></br>
            <h5 id='popular'>COMEDY</h5>
            <img src={require('../assets/image/red.png')} alt="Red" id='hrt2'></img>
            <br></br><br></br>  
            <div class="banner-container">
                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=tcdUhdOlz9M"><img src={require('../../src/assets/image/Other/Cinemas/Hollywood/Comedy/1.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=YnDeJn-BX5Q"><img src={require('../../src/assets/image/Other/Cinemas/Hollywood/Comedy/2.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=0qcc7dQKSZo"><img src={require('../../src/assets/image/Other/Cinemas/Hollywood/Comedy/3.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=R9TaHgLahHs"><img src={require('../../src/assets/image/Other/Cinemas/Hollywood/Comedy/4.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div  id='big-banner'>
                <a href="https://www.youtube.com/watch?v=bUSoEQBHtSg"><img src={require('../../src/assets/image/Other/Cinemas/Hollywood/Comedy/5.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

            </div>

            <br></br><br></br>
            <h5 id='popular'>NARRATIVE</h5>
            <img src={require('../assets/image/red.png')} alt="Red" id='hrt2'></img>
            <br></br><br></br>  
            <div class="banner-container">
                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=z7cEL6n24d4"><img src={require('../../src/assets/image/Other/Cinemas/Hollywood/Narrative/1.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=IJBnK2wNQSo"><img src={require('../../src/assets/image/Other/Cinemas/Hollywood/Narrative/2.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div id='big-banner'>
                <a href="https://www.youtube.com/watch?v=0ucTl-cxIjc"><img src={require('../../src/assets/image/Other/Cinemas/Hollywood/Narrative/3.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=pE3yR8bZ1pY"><img src={require('../../src/assets/image/Other/Cinemas/Hollywood/Narrative/4.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=x8UAUAuKNcU"><img src={require('../../src/assets/image/Other/Cinemas/Hollywood/Narrative/5.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

            </div>

            <br></br><br></br>
            <h5 id='popular'>KIDS</h5>
            <img src={require('../assets/image/red.png')} alt="Red" id='hrt2'></img>
            <br></br><br></br>  
            <div class="banner-container">
                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=jWM0ct-OLsM"><img src={require('../../src/assets/image/Other/Cinemas/Hollywood/Kids/1.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=m5fMyIImwEY"><img src={require('../../src/assets/image/Other/Cinemas/Hollywood/Kids/2.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=TbQm5doF_Uc"><img src={require('../../src/assets/image/Other/Cinemas/Hollywood/Kids/3.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=QaJbAennB_Q"><img src={require('../../src/assets/image/Other/Cinemas/Hollywood/Kids/4.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=gUTtJjV852c"><img src={require('../../src/assets/image/Other/Cinemas/Hollywood/Kids/5.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=87E6N7ToCxs"><img src={require('../../src/assets/image/Other/Cinemas/Hollywood/Kids/6.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

            </div>
            
        <div id='footer'><br></br><br></br><br></br>
          <span id="question">Questions? Call 000-800-919-1743</span>
          <div class="container mt-5">
              <div class="row">
                  <div class="col-md-3">
                      <div class="card1">
                          <div class="card-body">
                              <h5 class="card-title">FAQ</h5>
                              <h5 class="card-title">Invsetor relations</h5>
                              <h5 class="card-title">Privacy</h5>
                              <h5 class="card-title">Speed Test</h5>
                          </div>
                      </div>
                  </div>

                  <div class="col-md-3">
                      <div class="card1">
                          <div class="card-body">
                              <h5 class="card-title">Help Center</h5>
                              <h5 class="card-title">Jobs</h5>
                              <h5 class="card-title">Cookie Preferences</h5>
                              <h5 class="card-title">Legal Notices</h5>
                          </div>
                      </div>
                  </div>

                  <div class="col-md-3">
                      <div class="card1">
                          <div class="card-body">
                              <h5 class="card-title">Account</h5>
                              <h5 class="card-title">Ways to Watch</h5>
                              <h5 class="card-title">Information</h5>
                              <h5 class="card-title">Only On Netflix</h5>
                          </div>
                      </div>
                  </div>

                  <div class="col-md-3">
                      <div class="card1">
                          <div class="card-body">
                              <h5 class="card-title">Media Center</h5>
                              <h5 class="card-title">Terms of Use</h5>
                              <h5 class="card-title">Contact us</h5>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
          <br></br><br></br><br></br>
          <span id="india">Netflix India</span>
          <br></br><br></br><br></br>
        </div>
        
      </div>
    </div>
  );
}
