import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth } from '../components/FirebaseConfig';
import { createUserWithEmailAndPassword, fetchSignInMethodsForEmail } from 'firebase/auth';
import { Link } from 'react-router-dom';

export default function Two() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const email = localStorage.getItem('email');
  const password = localStorage.getItem('password');

  const handleSubmit = async () => {
    setLoading(true);
    setError(null);

    if (!email || !password) {
      setLoading(false);
      setError('Email or password is missing.');
      setTimeout(() => navigate('/'), 2000); // Redirect to '/' after 2 seconds
      return;
    }

    try {
      // Check if the email already exists in Firebase
      const signInMethods = await fetchSignInMethodsForEmail(auth, email);

      if (signInMethods.length > 0) {
        setLoading(false);
        setError('This email is already in use.');
        setTimeout(() => navigate('/'), 2000); // Redirect to '/' after 2 seconds
        return;
      }

      // Create user in Firebase Authentication
      await createUserWithEmailAndPassword(auth, email, password);
      alert('User registered successfully!');
      localStorage.clear(); // Clear localStorage after successful registration
      navigate('/Login'); // Redirect to login page
    } catch (err) {
      console.error('Error creating user:', err.message);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <img src={require('../assets/image/Netflix-logo.png')} id='logo' />
      <br />
      <Link to={'/Login'}>
        <button id='one-select'>SIGN IN</button>
      </Link>
      <br /><br />
      <hr />
      <div id='one-elements'>
        <img src={require('../assets/image/verify.png')} id='two-verifylogo' />
        <br /><br />
        <h5 id='one-step'>Step 2 of 2</h5>
        <br />
        <h3>Great, Now let us check your <br /> Email & Password</h3>
        <br />
        {/* Show error message immediately below the instruction */}
        {error && <p style={{ color: 'red' }}>{error}</p>}

        Email:<br />
        <input type="email" value={email || "No email provided"} readOnly id="two-email" />
        <br /><br />
        Password:<br />
        <input type="text" value={password || "No Password provided"} readOnly id="two-email" />
        <br /><br /><br />

        <button onClick={handleSubmit} disabled={loading} id='two-button'>
          {loading ? 'Submitting...' : 'Submit'}
        </button>
        <br /><br /><br />
      </div>
    </div>
  );
}
