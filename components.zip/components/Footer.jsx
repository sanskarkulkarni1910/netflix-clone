import React, { useState } from 'react';

export default function Footer() {
  return (
<div id='footer'><br></br><br></br><br></br>
<span id="question">Questions? Call 000-800-919-1743</span>
          <div class="container mt-5">
              <div class="row">
                  <div class="col-md-3">
                      <div class="card1">
                          <div class="card-body">
                              <h5 class="card-title">FAQ</h5>
                              <h5 class="card-title">Invsetor relations</h5>
                              <h5 class="card-title">Privacy</h5>
                              <h5 class="card-title">Speed Test</h5>
                          </div>
                      </div>
                  </div>

                  <div class="col-md-3">
                      <div class="card1">
                          <div class="card-body">
                              <h5 class="card-title">Help Center</h5>
                              <h5 class="card-title">Jobs</h5>
                              <h5 class="card-title">Cookie Preferences</h5>
                              <h5 class="card-title">Legal Notices</h5>
                          </div>
                      </div>
                  </div>

                  <div class="col-md-3">
                      <div class="card1">
                          <div class="card-body">
                              <h5 class="card-title">Account</h5>
                              <h5 class="card-title">Ways to Watch</h5>
                              <h5 class="card-title">Information</h5>
                              <h5 class="card-title">Only On Netflix</h5>
                          </div>
                      </div>
                  </div>

                  <div class="col-md-3">
                      <div class="card1">
                          <div class="card-body">
                              <h5 class="card-title">Media Center</h5>
                              <h5 class="card-title">Terms of Use</h5>
                              <h5 class="card-title">Contact us</h5>
                          </div>
                      </div>
                  </div>
              </div>
          </div>

          <br></br><br></br><br></br>
          <span id="india">Netflix India</span>
          <br></br><br></br><br></br>
</div>
          
);
}
