import React, { useState } from 'react';
import backgroundImage from '../assets/image/black1.png';
import logoImage from '../assets/image/Netflix-logo.png'; 

export default function Bollywood() {
  // State to control dropdown visibility
  const [isDropdownVisible, setIsDropdownVisible] = useState(false);

  // Function to toggle dropdown visibility
  const toggleDropdown = () => {
    setIsDropdownVisible(!isDropdownVisible);
  };

  // Function to close the dropdown after link click
  const handleLinkClick = () => {
    setIsDropdownVisible(false); 
  };

  return (
    <div id="header-container">
      <div className="overlay"></div>
      <img src={logoImage} id="logo" alt="Logo" />
        <div id="content" style={{ backgroundImage: `url(${backgroundImage})` }}>

          <nav>
            <img src={logoImage} id="logo" alt="Logo" />
            <br />
            <button id="house-navbar5"><a href="/House">HOME</a></button>
            <button id="house-navbar6">BOLLYWOOD</button>       

            <br></br><br></br>
            <hr id='house-hr'></hr>
          </nav>
          
            <br></br>
            <h5 id='popular'>HORROR</h5>
            <img src={require('../assets/image/red.png')} alt="Red" id='hrt2'></img>
            <br></br><br></br>         
            
             <div class="banner-container">
                <div id='big-banner'>
                <a href="https://www.youtube.com/watch?v=T_RJFveZBdI"><img src={require('../../src/assets/image/Other/Cinemas/Bollywood/Horror/1.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=gOZwaMCzCN4"><img src={require('../../src/assets/image/Other/Cinemas/Bollywood/Horror/5.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=paFgQNPGlsg"><img src={require('../../src/assets/image/Other/Cinemas/Bollywood/Horror/3.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=PQKu78NnyvU"><img src={require('../../src/assets/image/Other/Cinemas/Bollywood/Horror/4.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=iiRl8459LJ8"><img src={require('../../src/assets/image/Other/Cinemas/Bollywood/Horror/2.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>
            </div>

            <br></br><br></br>
            <h5 id='popular'>COMEDY</h5>
            <img src={require('../assets/image/red.png')} alt="Red" id='hrt2'></img>
            <br></br><br></br>  
            <div class="banner-container">
                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=JZm3ZphAR_M"><img src={require('../../src/assets/image/Other/Cinemas/Bollywood/Comedy/1.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=6f-EaUWCua0"><img src={require('../../src/assets/image/Other/Cinemas/Bollywood/Comedy/2.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=6XkbB1tS-Wc"><img src={require('../../src/assets/image/Other/Cinemas/Bollywood/Comedy/3.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=KvsN9l-_wnU"><img src={require('../../src/assets/image/Other/Cinemas/Bollywood/Comedy/4.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div  id='big-banner'>
                <a href="https://www.youtube.com/watch?v=qdBt_g2ST40"><img src={require('../../src/assets/image/Other/Cinemas/Bollywood/Comedy/5.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

            </div>

            <br></br><br></br>
            <h5 id='popular'>NARRATIVE</h5>
            <img src={require('../assets/image/red.png')} alt="Red" id='hrt2'></img>
            <br></br><br></br>  
            <div class="banner-container">

                <div id='big-banner'>
                <a href="https://www.youtube.com/watch?v=tMTNj_wWliE"><img src={require('../../src/assets/image/Other/Cinemas/Bollywood/Narrative/1.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div id='big-banner'>
                <a href="https://www.youtube.com/watch?v=Q0FTXnefVBA"><img src={require('../../src/assets/image/Other/Cinemas/Bollywood/Narrative/2.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div id='big-banner'>
                <a href="https://www.youtube.com/watch?v=nsC5PhXS19Y"><img src={require('../../src/assets/image/Other/Cinemas/Bollywood/Narrative/4.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

            </div>

            <br></br><br></br>
            <h5 id='popular'>KIDS</h5>
            <img src={require('../assets/image/red.png')} alt="Red" id='hrt2'></img>
            <br></br><br></br>  
            <div class="banner-container">
                <div id='big-banner'>
                <a href="https://www.youtube.com/watch?v=TDaca3aJlRQ"><img src={require('../../src/assets/image/Other/Cinemas/Bollywood/Kids/1.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div id='big-banner'>
                <a href="https://www.youtube.com/watch?v=2mGYh8MTivk"><img src={require('../../src/assets/image/Other/Cinemas/Bollywood/Kids/2.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div id='big-banner'>
                <a href="https://www.youtube.com/watch?v=-23lgFMgTj4"><img src={require('../../src/assets/image/Other/Cinemas/Bollywood/Kids/3.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

            </div>
            
        <div id='footer'><br></br><br></br><br></br>
          <span id="question">Questions? Call 000-800-919-1743</span>
          <div class="container mt-5">
              <div class="row">
                  <div class="col-md-3">
                      <div class="card1">
                          <div class="card-body">
                              <h5 class="card-title">FAQ</h5>
                              <h5 class="card-title">Invsetor relations</h5>
                              <h5 class="card-title">Privacy</h5>
                              <h5 class="card-title">Speed Test</h5>
                          </div>
                      </div>
                  </div>

                  <div class="col-md-3">
                      <div class="card1">
                          <div class="card-body">
                              <h5 class="card-title">Help Center</h5>
                              <h5 class="card-title">Jobs</h5>
                              <h5 class="card-title">Cookie Preferences</h5>
                              <h5 class="card-title">Legal Notices</h5>
                          </div>
                      </div>
                  </div>

                  <div class="col-md-3">
                      <div class="card1">
                          <div class="card-body">
                              <h5 class="card-title">Account</h5>
                              <h5 class="card-title">Ways to Watch</h5>
                              <h5 class="card-title">Information</h5>
                              <h5 class="card-title">Only On Netflix</h5>
                          </div>
                      </div>
                  </div>

                  <div class="col-md-3">
                      <div class="card1">
                          <div class="card-body">
                              <h5 class="card-title">Media Center</h5>
                              <h5 class="card-title">Terms of Use</h5>
                              <h5 class="card-title">Contact us</h5>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
          <br></br><br></br><br></br>
          <span id="india">Netflix India</span>
          <br></br><br></br><br></br>
        </div>
      </div>
    </div>
  );
}
