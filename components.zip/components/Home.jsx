import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import backgroundImage from '../assets/image/background.jpg'; // Import the background image
import logoImage from '../assets/image/Netflix-logo.png'; // Import the logo image

export default function Home() {
  const [email, setEmail] = useState('');
  const navigate = useNavigate(); // Use useNavigate instead of useHistory

  const handleEmailChange = (event) => {
    setEmail(event.target.value);
  };

  const handleEmailSubmit = (event) => {
    event.preventDefault();
    if (email) {
      localStorage.setItem('email', email); // Store email in local storage
      navigate('/one'); // Redirect to password page
    }
  };
  return (
    <div id="header-container" style={{ backgroundImage: `url(${backgroundImage})` }}>
      <div className="overlay"></div>
        <img src={logoImage} id="logo" alt="Logo" />
      <div id="content">

    <select id="select">
        <option value="english">
        <i class="fa-solid fa-globe"></i> ENGLISH
        </option>
    </select>
        
        <Link to={'/Login'}>
         <button>SIGN IN</button>
        </Link>        
            <br></br>
          <h1 id="unlimited"><span>&nbsp;UNLIMITED MOVIES,</span><br></br> TV SHOWS AND MORE</h1>
          <br></br>
          <h5 id="start"><br></br><span>Ready to watch? Enter your email to create or restart your membership.</span></h5>
          <br></br>
          
          <form id="usernameForm" onSubmit={handleEmailSubmit} required>
          <input
            type="email"
            placeholder="Enter Your Email"
            id="text"
            value={email}
            onChange={handleEmailChange}
            required
          />
          <button type="submit" id="get">
            Get Started &nbsp;&nbsp;<i className="fa-solid fa-greater-than"></i>
          </button>
        </form>

        <br></br>
        <div id="black">
        <img src={require('../assets/image/red.png')} alt="Red" id="hrt"/>          
        <br></br><br></br>
          <span id="trending">Trending Now</span><br></br>
          <select id="select1">
          <option value="english">India</option>
          </select>
            <select id="select2">
            <option value="english">Movies</option>
          </select>
          <br></br><br></br><br></br><br></br>

          {/* CAROUSEL START */}
          <div class="container">
            <div class="carousel slide" data-bs-ride="carousel" id="mainparent">
                <div class="carousel-indicators">
                    <button type="button" class="active" data-bs-slide-to="0" data-bs-target="#mainparent" id="line"></button>
                    <button type="button" data-bs-slide-to="1" data-bs-target="#mainparent" id="line"></button>
                    <button type="button" data-bs-slide-to="2" data-bs-target="#mainparent" id="line"></button>
                    <button type="button" data-bs-slide-to="3" data-bs-target="#mainparent" id="line"></button>
                </div>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src={require('../assets/image/banner4.jpg')} class="w-100" height="550px" alt=""/>
                    </div>
                    <div class="carousel-item">
                        <img src={require('../assets/image/banner2.jpg')} class="w-100" height="550px" alt=""/>
                    </div>
                    <div class="carousel-item">
                        <img src={require('../assets/image/banner3.jpg')} class="w-100" height="550px" alt=""/>
                    </div>
                    <div class="carousel-item">
                        <img src={require('../assets/image/banner1.jpg')} class="w-100" height="550px" alt=""/>
                    </div>
                </div>
                <button type="button" class="carousel-control-prev bg-warning" data-bs-slide="prev" data-bs-target="#mainparent" id="line1">
                    <span class="carousel-control-prev-icon"></span>
                </button>
                <button type="button" class="carousel-control-next bg-warning" data-bs-slide="next" data-bs-target="#mainparent" id="line1">
                    <span class="carousel-control-next-icon"></span>
                </button>
            </div>
        </div>
          {/* CAROUSEL END */}
          <br></br><br></br><br></br>
          <span id="more">More reasons to join</span>
          {/* CARDS START */}
          <div class="container mt-5">
              <div class="row">
                  <div class="col-md-3">
                      <div class="card">
                          <div class="card-body">
                              <h5 class="card-title">Enjoy on your TV</h5>
                              <p class="card-text">Watch on smart TVs, PlayStation, Xbox, Chromecast, Apple TV, Blu-ray players and more.</p>
                              <br></br><br></br><br></br><i class="fa-solid fa-tv" id="download"></i>
                          </div>
                      </div>
                  </div>

                  <div class="col-md-3">
                      <div class="card">
                          <div class="card-body">
                              <h5 class="card-title">Download your shows to watch offline</h5>
                              <p class="card-text">Save your favourites easily and always have something to watch.</p><br></br>
                              <br></br><br></br><br></br><i class="fa-solid fa-circle-down" id="download"></i>
                          </div>
                      </div>
                  </div>

                  <div class="col-md-3">
                      <div class="card">
                          <div class="card-body">
                              <h5 class="card-title">Watch everywhere</h5>
                              <p class="card-text">Stream unlimited movies and TV shows on your phone, tablet, laptop and TV.</p>
                              <br></br><br></br><br></br><br></br><i class="fa-solid fa-satellite" id="download"></i>
                          </div>
                      </div>
                  </div>

                  <div class="col-md-3">
                      <div class="card">
                          <div class="card-body">
                              <h5 class="card-title">Create profiles for kids</h5>
                              <p class="card-text">Send kids on adventures with their favourite characters in a space made just for them — free with your membership.</p>
                              <br></br><i class="fa-solid fa-face-kiss-beam" id="download1"></i>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
          {/* CARDS END */}
          <br></br><br></br><br></br>

          <span id="more">Frequently Asked Questions</span><br></br><br></br>

          {/* Freqnently Start */}
            <div class="accordion">

                <div class="accordion-item" id="item2">
                    <input type="checkbox" id="question1"/>
                    <label class="accordion-header" for="question1">
                        <span>What is Netflix?</span>
                    </label>
                    <div class="accordion-content" id="item1">
                    Netflix is a streaming service that offers a wide variety of award-winning TV shows, movies, anime, documentaries and more – on thousands of internet-connected devices.
                    <br></br><br></br>
                    You can watch as much as you want, whenever you want, without a single ad – all for one low monthly price. There's always something new to discover, and new TV shows and movies are added every week!                
                    </div>
                </div>

                <div class="accordion-item" id="item2">
                    <input type="checkbox" id="question2"/>
                    <label class="accordion-header" for="question2">
                        <span>How Much Does Netflix Cost?</span>
                    </label>
                    <div class="accordion-content" id="item1">
                    Watch Netflix on your smartphone, tablet, Smart TV, laptop, or streaming device, all for one fixed monthly fee. Plans range from Rs.149 to Rs.649 a month. No extra costs, no contracts.                
                    </div>
                </div>

                <div class="accordion-item" id="item2">
                    <input type="checkbox" id="question3"/>
                    <label class="accordion-header" for="question3">
                        <span>Where Can I Watch?</span>
                    </label>
                    <div class="accordion-content" id="item1">
                    Watch anywhere, anytime. Sign in with your Netflix account to watch instantly on the web at netflix.com from your personal computer or on any internet-connected device that offers the Netflix app, including smart TVs, smartphones, tablets, streaming media players and game consoles.
                    <br></br><br></br>
                    You can also download your favourite shows with the iOS or Android app. Use downloads to watch while you're on the go and without an internet connection. Take Netflix with you anywhere.                
                    </div>
                </div>

                <div class="accordion-item" id="item2">
                    <input type="checkbox" id="question4"/>
                    <label class="accordion-header" for="question4">
                        <span>How Do I Cancel?</span>
                    </label>
                    <div class="accordion-content" id="item1">
                    Netflix is flexible. There are no annoying contracts and no commitments. You can easily cancel your account online in two clicks. There are no cancellation fees – start or stop your account anytime.                
                    </div>
                </div>

                <div class="accordion-item" id="item2">
                    <input type="checkbox" id="question5"/>
                    <label class="accordion-header" for="question5">
                        <span>What Can I Watch on Netflix?</span>
                    </label>
                    <div class="accordion-content" id="item1">
                    Netflix has an extensive library of feature films, documentaries, TV shows, anime, award-winning Netflix originals, and more. Watch as much as you want, anytime you want.                
                    </div>     
                </div>

                <div class="accordion-item" id="item2">
                    <input type="checkbox" id="question6"/>
                    <label class="accordion-header" for="question6">
                        <span>Is Netflix Good for Childern?</span>
                    </label>
                    <div class="accordion-content" id="item1">
                    The Netflix Kids experience is included in your membership to give parents control while kids enjoy family-friendly TV shows and films in their own space.
                    <br></br><br></br>
                    Kids profiles come with PIN-protected parental controls that let you restrict the maturity rating of content kids can watch and block specific titles you don’t want kids to see.                    
                    </div>     
                </div>

            </div>    
          {/* Freqnently End */}
        <br></br><br></br>
        
        </div>
        </div>
        <div id='footer'><br></br><br></br><br></br>
          <span id="question">Questions? Call 000-800-919-1743</span>
          <div class="container mt-5">
              <div class="row">
                  <div class="col-md-3">
                      <div class="card1">
                          <div class="card-body">
                              <h5 class="card-title">FAQ</h5>
                              <h5 class="card-title">Invsetor relations</h5>
                              <h5 class="card-title">Privacy</h5>
                              <h5 class="card-title">Speed Test</h5>
                          </div>
                      </div>
                  </div>

                  <div class="col-md-3">
                      <div class="card1">
                          <div class="card-body">
                              <h5 class="card-title">Help Center</h5>
                              <h5 class="card-title">Jobs</h5>
                              <h5 class="card-title">Cookie Preferences</h5>
                              <h5 class="card-title">Legal Notices</h5>
                          </div>
                      </div>
                  </div>

                  <div class="col-md-3">
                      <div class="card1">
                          <div class="card-body">
                              <h5 class="card-title">Account</h5>
                              <h5 class="card-title">Ways to Watch</h5>
                              <h5 class="card-title">Information</h5>
                              <h5 class="card-title">Only On Netflix</h5>
                          </div>
                      </div>
                  </div>

                  <div class="col-md-3">
                      <div class="card1">
                          <div class="card-body">
                              <h5 class="card-title">Media Center</h5>
                              <h5 class="card-title">Terms of Use</h5>
                              <h5 class="card-title">Contact us</h5>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
          <br></br><br></br><br></br>
          <span id="india">Netflix India</span>
          <br></br><br></br><br></br>
        </div>
    </div>
  );
}
