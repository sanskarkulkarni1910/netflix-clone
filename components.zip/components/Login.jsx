import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom'; // Import useNavigate for redirection
import backgroundImage from '../assets/image/background.jpg';
import logoImage from '../assets/image/Netflix-logo.png';

// Import the default export from FirebaseConfig.jsx (or FirebaseApp.js)
import app from '../components/FirebaseConfig'; // Correct way to import the default export
import { getAuth, signInWithEmailAndPassword } from 'firebase/auth';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const auth = getAuth(app);
  const navigate = useNavigate(); // Hook to navigate programmatically

  // Handle the form submission and sign-in
  const onSignInSubmitHandler = async (e) => {
    e.preventDefault();
    try {
      // Use Firebase authentication to sign in with email and password
      await signInWithEmailAndPassword(auth, email, password);

      // Redirect to the main page
      navigate('/House');  // Assuming '/main' is the path you want to navigate to
    } catch (error) {
      setErrorMessage('Error! Invalid Email or Password'); // Set error message if authentication fails
      
      // Reset email and password fields after showing the error message
      setEmail('');
      setPassword('');
    }
  };

  const emailOnChangeHandler = (e) => {
    setEmail(e.target.value);
  };

  const passwordOnChangeHandler = (e) => {
    setPassword(e.target.value);
  };

  return (
    <div id="header" style={{ backgroundImage: `url(${backgroundImage})` }}>
      <div className="over"></div>
      <img src={logoImage} id="logo" alt="Logo" />
      <div id="content"><br /><br />
        <div id="loginbox">
          <h3 id="in">SIGN IN</h3><br /><br />
          <form onSubmit={onSignInSubmitHandler}>
            {/* Display error message above email input */}
            {errorMessage && <div style={{ color: 'red', marginBottom: '20px', marginLeft: '50px', marginTop: '-30px' }}>{errorMessage}</div>}
            <input
              type="email"
              value={email}
              onChange={emailOnChangeHandler}
              id="loginemail"
              placeholder="Enter Your Username"
              required
            />
            <br /><br />
            <input
              type="password"
              value={password}
              onChange={passwordOnChangeHandler}
              id="loginemail"
              placeholder="Enter Your Password"
              required
            />
            <br /><br />
            <button type="submit" id="btnlogin">SIGN IN</button><br /><br />
          </form>
          <span id="or">OR</span>
          <br /><br />
          <span id="fp">
            <Link to="/Forgot" id="fp1">FORGOT PASSWORD?</Link>
          </span>
          <br /><br />
          <span id="fp">
            NEW TO NETFLIX&nbsp;&nbsp;<i className="fa-solid fa-greater-than"></i>
            <Link to="/" id="signup">&nbsp;&nbsp;SIGN UP NOW</Link>
          </span>
        </div>
      </div>
    </div>
  );
}
