import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { getAuth, sendPasswordResetEmail } from 'firebase/auth';
import backgroundImage from '../assets/image/black.png';
import logoImage from '../assets/image/Netflix-logo.png';

export default function Forgot() {
  const [inputValue, setInputValue] = useState(''); // User input
  const [errorMessage, setErrorMessage] = useState(''); // Error messages
  const [successMessage, setSuccessMessage] = useState(''); // Success messages
  const [loading, setLoading] = useState(false); // Loading state

  const auth = getAuth();

  const handleForgotPassword = async () => {
    setErrorMessage('');
    setSuccessMessage('');
    setLoading(true);

    // Validate input
    if (!inputValue) {
      setErrorMessage('Email address is required.');
      setLoading(false);
      return;
    }

    try {
      // Send password reset email
      await sendPasswordResetEmail(auth, inputValue);
      setSuccessMessage('Email sent successfully.');
      setInputValue(''); // Clear input field
    } catch (error) {
      setErrorMessage(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div id="header" style={{ backgroundImage: `url(${backgroundImage})` }}>
      <div className="over"></div>
      <img src={logoImage} id="logo" alt="Logo" />
      <br />
      <div id="content">
        <Link to="/Login" id="signin">SIGN IN</Link>
        <br /><br />
        <br></br><br></br>
        <div id="forgotbox">
          <span id="update">Update password or email</span>
          <br /><br />
          <span id="forgotline">Reset your password via email</span>
          <br /><br />

          <p id="forgot-sentence">
            We’ll send an Email from Netflix with instructions to reset your password.
          </p>

          {/* Input field for email */}
          <input
            type="email"
            id="emaillogin"
            placeholder="Enter Your Email Address"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            required
          />
          <br /><br />

          {/* Error and success messages */}
          {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}
          {successMessage && <p style={{ color: 'green', marginLeft: '100px' }}>{successMessage}</p>}

          <br />

          {/* Submit button */}
          <button id="forgotbtn" onClick={handleForgotPassword} disabled={loading}>
            {loading ? 'Sending...' : 'FORGOT PASSWORD'}
          </button>
        </div>
      </div>
    </div>
  );
}
