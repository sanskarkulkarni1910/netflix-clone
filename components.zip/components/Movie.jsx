import React, { useState } from 'react';
import backgroundImage from '../assets/image/black1.png'; 
import logoImage from '../assets/image/Netflix-logo.png'; 

export default function Movie() {
  // State to control dropdown visibility
  const [isDropdownVisible, setIsDropdownVisible] = useState(false);

  // Function to toggle dropdown visibility
  const toggleDropdown = () => {
    setIsDropdownVisible(!isDropdownVisible);
  };

  // Function to close the dropdown after link click
  const handleLinkClick = () => {
    setIsDropdownVisible(false); 
  };

  return (
    <div id="header-container">
      <div className="overlay"></div>
      <img src={logoImage} id="logo" alt="Logo" />
        <div id="content" style={{ backgroundImage: `url(${backgroundImage})` }}>

          <nav>
            <img src={logoImage} id="logo" alt="Logo" />
            <br />
            <button id="house-navbar5"><a href="/House">HOME</a></button>
            <button id="house-navbar6">MOVIES</button>       

            <br></br><br></br>
            <hr id='house-hr'></hr>
          </nav>
          
            <br></br>
            <h5 id='popular'>HORROR</h5>
            <img src={require('../assets/image/red.png')} alt="Red" id='hrt2'></img>
            <br></br><br></br>         
            
             <div class="banner-container">
                <div id='big-banner'>
                <a href="https://www.youtube.com/watch?v=gaaSydGkRCA"><img src={require('../../src/assets/image/Other/Movie/Horror/1.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=FWKCoBpmp-U"><img src={require('../../src/assets/image/Other/Movie/Horror/2.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=82I1ErFD63U"><img src={require('../../src/assets/image/Other/Movie/Horror/3.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div id='big-banner'>
                <a href="https://www.youtube.com/watch?v=smTK_AeAPHs"><img src={require('../../src/assets/image/Other/Movie/Horror/4.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>
            </div>

            <br></br><br></br>
            <h5 id='popular'>COMEDY</h5>
            <img src={require('../assets/image/red.png')} alt="Red" id='hrt2'></img>
            <br></br><br></br>  
            <div class="banner-container">
                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=pCMHc-IFAB0"><img src={require('../../src/assets/image/Other/Movie/Comedy/1.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=fa2RZf0m39g"><img src={require('../../src/assets/image/Other/Movie/Comedy/2.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=8nUwpoTrWFk"><img src={require('../../src/assets/image/Other/Movie/Comedy/3.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=fo9EhcwQXcM"><img src={require('../../src/assets/image/Other/Movie/Comedy/4.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div  id='big-banner'>
                <a href="https://www.youtube.com/watch?v=RbIxYm3mKzI"><img src={require('../../src/assets/image/Other/Movie/Comedy/5.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

            </div>

            <br></br><br></br>
            <h5 id='popular'>NARRATIVE</h5>
            <img src={require('../assets/image/red.png')} alt="Red" id='hrt2'></img>
            <br></br><br></br>  
            <div class="banner-container">
                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=VgGgYOzNWno"><img src={require('../../src/assets/image/Other/Movie/Narrative/1.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=kQDd1AhGIHk"><img src={require('../../src/assets/image/Other/Movie/Narrative/2.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div id='big-banner'>
                <a href="https://www.youtube.com/watch?v=OwlynHlZEc4"><img src={require('../../src/assets/image/Other/Movie/Narrative/4.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=iAt_j6zEeF0"><img src={require('../../src/assets/image/Other/Movie/Narrative/3.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=unCIKO7-PSQ"><img src={require('../../src/assets/image/Other/Movie/Narrative/5.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

            </div>

            <br></br><br></br>
            <h5 id='popular'>KIDS</h5>
            <img src={require('../assets/image/red.png')} alt="Red" id='hrt2'></img>
            <br></br><br></br>  
            <div class="banner-container">
                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=FTqLUEpWqEc"><img src={require('../../src/assets/image/Other/Movie/Kids/1.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=CaimKeDcudo"><img src={require('../../src/assets/image/Other/Movie/Kids/2.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=vjnqABgxfO0"><img src={require('../../src/assets/image/Other/Movie/Kids/3.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=IeFWNtMo1Fs"><img src={require('../../src/assets/image/Other/Movie/Kids/4.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=Rvr68u6k5sI"><img src={require('../../src/assets/image/Other/Movie/Kids/5.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

                <div class="banner" id='big-banner'>
                <a href="https://www.youtube.com/watch?v=TwXgOMDONK8"><img src={require('../../src/assets/image/Other/Movie/Kids/6.jpg')} alt="Red" id='big-banner-img'></img></a>
                </div>

            </div>
            
        <div id='footer'><br></br><br></br><br></br>
          <span id="question">Questions? Call 000-800-919-1743</span>
          <div class="container mt-5">
              <div class="row">
                  <div class="col-md-3">
                      <div class="card1">
                          <div class="card-body">
                              <h5 class="card-title">FAQ</h5>
                              <h5 class="card-title">Invsetor relations</h5>
                              <h5 class="card-title">Privacy</h5>
                              <h5 class="card-title">Speed Test</h5>
                          </div>
                      </div>
                  </div>

                  <div class="col-md-3">
                      <div class="card1">
                          <div class="card-body">
                              <h5 class="card-title">Help Center</h5>
                              <h5 class="card-title">Jobs</h5>
                              <h5 class="card-title">Cookie Preferences</h5>
                              <h5 class="card-title">Legal Notices</h5>
                          </div>
                      </div>
                  </div>

                  <div class="col-md-3">
                      <div class="card1">
                          <div class="card-body">
                              <h5 class="card-title">Account</h5>
                              <h5 class="card-title">Ways to Watch</h5>
                              <h5 class="card-title">Information</h5>
                              <h5 class="card-title">Only On Netflix</h5>
                          </div>
                      </div>
                  </div>

                  <div class="col-md-3">
                      <div class="card1">
                          <div class="card-body">
                              <h5 class="card-title">Media Center</h5>
                              <h5 class="card-title">Terms of Use</h5>
                              <h5 class="card-title">Contact us</h5>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
          <br></br><br></br><br></br>
          <span id="india">Netflix India</span>
          <br></br><br></br><br></br>
        </div>
      </div>
    </div>
  );
}
